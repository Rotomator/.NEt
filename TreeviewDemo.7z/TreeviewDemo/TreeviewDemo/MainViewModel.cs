﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Collections.ObjectModel;

namespace TreeviewDemo
{
    public class MainViewModel : ViewModelBase
    {
        private SampleData _data;
        private static MainViewModel _this;
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel()
        {
            this.Data = new SampleData();
            _this = this;

        }

        public static MainViewModel GetInstance()
        {
            return _this;
        }
        public SampleData Data
        {
            get { return _data; }
            set
            {
                if (Equals(value, _data)) return;
                _data = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<TreeNode> _treeCollection2;

        public ObservableCollection<TreeNode> TreeCollection2
        {
            get { return _treeCollection2; }
            set
            {
                _treeCollection2 = value;
            }
        }

        //public ObservableCollection<TreeNode> getTreeCollection2Value()
        //{

        //    items = Data.TreeCollection2;
        //    return items;
        //}

        //public void DragOver(IDropInfo dropInfo)
        //{
        //    TreeNode sourceItem = dropInfo.Data as TreeNode;
        //    TreeNode targetItem = dropInfo.TargetItem as TreeNode;
        //    dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
        //    if (sourceItem.Caption == "Stage")
        //    {
        //        dropInfo.Effects = DragDropEffects.Move;
        //    }
        //    else
        //        dropInfo.Effects = DragDropEffects.Copy;
        //}

        //public void Drop(IDropInfo dropInfo)
        //{
        //    TreeNode sourceItem = dropInfo.Data as TreeNode;
        //    if (sourceItem.Caption == "Stage")
        //    {

        //        var root1 = new TreeNode($"Stage");
        //        Data.TreeCollection2.Add(root1);
        //    }
        //    else
        //    {
        //        MessageBox.Show("A JOB can only be dropped inside a STAGE!");
        //        //var root1 = new TreeNode($"Stage");
        //        //var child = sourceItem.Children;
        //        //root1.Children.Add(new TreeNode(child.ToString()));
        //        //Data.TreeCollection2.Add(root1);
        //    }
        //    //items = Data.TreeCollection2;
        //    //this.treeNode2Data = Data.TreeCollection2;
        //    this.TreeCollection2 = Data.TreeCollection2;
        //}
    }
}