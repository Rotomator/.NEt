﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Threading.Tasks;

namespace TreeviewDemo
{
    public class SampleData
    {
        //Used if Default Drop Handler not used
        private static SampleData _this;
        public SampleData()
        {
            var root1 = new TreeNode($"STAGES");
            root1.Children.Add(new TreeNode($"Stage"));
            this.TreeCollection1.Add(root1);

            var root2 = new TreeNode($"PREDEFINED JOBS");
            root2.Children.Add(new TreeNode($"Compile (MSBuild)"));
            root2.Children.Add(new TreeNode($"Static Code Analysis (MSBuild)"));
            root2.Children.Add(new TreeNode($"Unit Test (TDD)"));
            root2.Children.Add(new TreeNode($"Deploy (IIS)"));
            root2.Children.Add(new TreeNode($"Docker Image Creation"));
            root2.Children.Add(new TreeNode($"Docker Push"));
            this.TreeCollection1.Add(root2);

            var root7 = new TreeNode($"Sub");
            root7.Children.Add(root2);
            root7.Children.Add(root1);
            this.TreeCollection1.Add(root7);

            var root3 = new TreeNode($"CUSTOM JOBS");
            root3.Children.Add(new TreeNode($"MSBuild Job"));
            root3.Children.Add(new TreeNode($"Maven Job"));
            root3.Children.Add(new TreeNode($"Docker Job"));
            root3.Children.Add(new TreeNode($"CF Job"));
            root3.Children.Add(new TreeNode($"Shell Job"));
            this.TreeCollection1.Add(root3);
            //Used if Default Drop Handler not used
            _this = this;

            var root4 = new TreeNode();
            this.TreeCollection2.Add(root4);


        }

        //Used if Default Drop Handler not used
        public static SampleData GetInstance()
        {
            return _this;
        }

        public ObservableCollection<TreeNode> TreeCollection1 { get; set; } = new ObservableCollection<TreeNode>();
        public ObservableCollection<TreeNode> TreeCollection2 { get; set; } = new ObservableCollection<TreeNode>();
    }
}