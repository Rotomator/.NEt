﻿using DotNet_ADC.UControls.UCDesignPipeline;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNet_ADC
{
    class RoboViewModel : ViewModelBase
    {
        private Command_CurrentFile _data;
        private static RoboViewModel _this;

        public RoboViewModel()
        {
            this.Data = new Command_CurrentFile();
            _this = this;
        }

        public static RoboViewModel GetInstance()
        {
            return _this;
        }

        public Command_CurrentFile Data
        {
            get { return _data; }
            set
            {
                if (Equals(value, _data)) return;
                _data = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<TreeNode> _treeCollection3;

        public ObservableCollection<TreeNode> TreeCollection3
        {
            get { return _treeCollection3; }
            set
            {
                _treeCollection3 = value;
            }
        }
    }
}
