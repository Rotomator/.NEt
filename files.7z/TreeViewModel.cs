﻿using DotNet_ADC.UControls.UCDesignPipeline;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotNet_ADC
{
    class TreeViewModel : ViewModelBase
    {
        private Command_CurrentFile _data;
        private static TreeViewModel _this;

        public TreeViewModel()
        {
            this.Data = new Command_CurrentFile();
            _this = this;
        }

        //public SampleData Data
        //{
        //    get { return _data; }
        //    set
        //    {
        //        if (Equals(value, _data)) return;
        //        _data = value;
        //        OnPropertyChanged();
        //    }
        //}

        public Command_CurrentFile Data
        {
            get { return _data; }
            set
            {
                if (Equals(value, _data)) return;
                _data = value;
                OnPropertyChanged();
            }
        }

        public static TreeViewModel GetInstance()
        {
            return _this;
        }
    }
}
