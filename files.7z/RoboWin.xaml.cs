﻿using DotNet_ADC.UControls.UCDesignPipeline;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DotNet_ADC
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class RoboWin : Window
    {
        private ObservableCollection<TreeNode> treeCollection3;

        // public static ObservableCollection<TreeNode> TreeCollection = new SampleData().TreeCollection1;
        // private ObservableCollection<TreeNode> treeCollection3;

        public RoboWin()
        {
            InitializeComponent();
            this.DataContext = new RoboViewModel().TreeCollection3;
        }

        public RoboWin(ObservableCollection<TreeNode> treeCollection3)
        {
            this.treeCollection3 = treeCollection3;
            this.DataContext = treeCollection3;
        }

        //public RoboWin(ObservableCollection<TreeNode> treeCollection3)
        //{
        //    this.treeCollection3 = treeCollection3;
        //    AddToTree(treeCollection3);
        //}

        //private void AddToTree(ObservableCollection<TreeNode> TreeCollection)
        //{

        //    foreach (var items in TreeCollection)
        //    {
        //        var parent = new TreeViewItem()
        //        {
        //            Header = new CheckBox
        //            {
        //                Content = items.Caption,
        //                IsThreeState = true
        //            }
        //        };

        //        tree.Items.Add(parent);

        //        var count = items.Children.Count();

        //        while (count != 0)
        //        {

        //            var child = new TreeViewItem()
        //            {
        //                Header = new CheckBox
        //                {
        //                    Content = items.Children[count - 1]
        //                }
        //            };

        //            parent.Items.Add(child);

        //            count--;
        //        }
        //    }
        //}

        //private void CheckBox_Checked(object sender, RoutedEventArgs e)
        //{

        //}
    }
}
