﻿//------------------------------------------------------------------------------
// <copyright file="Command_CurrentFile.cs" company="Company">
//     Copyright (c) Company.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

using System;
using System.ComponentModel.Design;
using System.Globalization;
using Microsoft.VisualStudio.Shell;
using EnvDTE;
using System.Windows;
using EnvDTE80;
using System.Text;
using DotNet_ADC.UControls.UCDesignPipeline;
using System.Collections.ObjectModel;
using System.Collections.Generic;


namespace DotNet_ADC
{
    /// <summary>
    /// Command handler
    /// </summary>
    internal sealed class Command_CurrentFile: ViewModelBase
    {
        private static Command_CurrentFile _this;
        //private SampleData _data;

        public static Command_CurrentFile GetInstance()
        {
            return _this;
        }
        //public SampleData Data
        //{
        //    get { return _data; }
        //    set
        //    {
        //        if (Equals(value, _data)) return;
        //        _data = value;
        //        OnPropertyChanged();
        //    }
        //}


        public Command_CurrentFile()
        {
           // this.Data = new SampleData();
            _this = this;
            MessageBox.Show("Hey! I'm inside Command!");
        }

        public ObservableCollection<TreeNode> TreeCollection3 { get; set; } = new ObservableCollection<TreeNode>();

        //public ObservableCollection<TreeNode> TreeCollection3
        //{
        //    get { return _treeCollection3; }
        //    set
        //    {
        //        _treeCollection3 = value;
        //    }
        //}

        /// <summary>
        /// Command ID.
        /// </summary>
        public const int CommandId = 4129;

        /// <summary>
        /// Command menu group (command set GUID).
        /// </summary>
        public static readonly Guid CommandSet = new Guid("0cfffe45-2655-4e9d-936e-d7225bfcd50a");

        /// <summary>
        /// VS Package that provides this command, not null.
        /// </summary>
        private readonly Package package;

        /// <summary>
        /// Initializes a new instance of the <see cref="Command_CurrentFile"/> class.
        /// Adds our command handlers for menu (commands must exist in the command table file)
        /// </summary>
        /// <param name="package">Owner package, not null.</param>
        private Command_CurrentFile(Package package)
        {
            if (package == null)
            {
                throw new ArgumentNullException("package");
            }

            this.package = package;

            OleMenuCommandService commandService = this.ServiceProvider.GetService(typeof(IMenuCommandService)) as OleMenuCommandService;
            if (commandService != null)
            {
                var menuCommandID = new CommandID(CommandSet, CommandId);
                var menuItem = new MenuCommand(this.MenuItemCallback, menuCommandID);
                commandService.AddCommand(menuItem);
            }
        }

        /// <summary>
        /// Gets the instance of the command.
        /// </summary>
        public static Command_CurrentFile Instance
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets the service provider from the owner package.
        /// </summary>
        private IServiceProvider ServiceProvider
        {
            get
            {
                return this.package;
            }
        }

        /// <summary>
        /// Initializes the singleton instance of the command.
        /// </summary>
        /// <param name="package">Owner package, not null.</param>
        public static void Initialize(Package package)
        {
            Instance = new Command_CurrentFile(package);
        }

        /// <summary>
        /// This function is the callback used to execute the command when the menu item is clicked.
        /// See the constructor to see how the menu item is associated with this function using
        /// OleMenuCommandService service and MenuCommand class.
        /// </summary>
        /// <param name="sender">Event sender.</param>
        /// <param name="e">Event args.</param>
        private void MenuItemCallback(object sender, EventArgs e)
        {
            string title = "Command_CurrentFile";

            //Opens a solution from path
            //string filePath = @"D:\VSIX\TestVSIX_1\TestVSIX_1.sln";
            //DTE2 dte = (DTE2)Microsoft.VisualStudio.Shell.ServiceProvider.GlobalProvider.GetService(typeof(DTE));
            //dte.Solution.Open(filePath);

            //To get Hierarchy structure
            UIHierarchyItemsExample();

            //string path = GetSourceFilePath();
        }

        public ObservableCollection<TreeNode> TreeCollectionRobo { get; set; } = new ObservableCollection<TreeNode>();

        public static DTE2 GetCurrentDTE(IServiceProvider provider)
        {
            DTE2 vs = (DTE2)provider.GetService(typeof(DTE));
            if (vs == null) throw new InvalidOperationException("DTE not found.");
            return vs;
        }

        public static DTE2 GetCurrentDTE()
        {
            return GetCurrentDTE(Microsoft.VisualStudio.Shell.ServiceProvider.GlobalProvider);
        }

        public void UIHierarchyItemsExample()
        {
            StringBuilder sb = new StringBuilder();
            DTE2 dte = GetCurrentDTE();
            int count = ((EnvDTE.SolutionClass)dte.Solution).Projects.Count;

            //Solution solution = dte.Solution;
            //foreach (Project proj in solution.Projects)
            //{
            RecurseItems(dte.ToolWindows.SolutionExplorer.UIHierarchyItems,
                            0, sb);
            //}

            SampleData data = new SampleData();
            //System.Windows.Window win = new Window1();
            //win.Show();

            MessageBox.Show(
                "Solution Explorer contains the following items: " +
                TreeCollection3);

            new RoboWin(TreeCollection3).Show();
        }
        TreeNode root;

        void RecurseItems(UIHierarchyItems items, int level, StringBuilder sb)
        {
            if (!items.Expanded)
                items.Expanded = true;

            foreach (UIHierarchyItem item in items)
            {
                //UIHierarchyItem parent = ((UIHierarchyItem)items.Parent);
                if (level == 0)
                {
                    MessageBox.Show("Level O " + item.Name);
                }
                else if (level == 1)
                {
                    root = new TreeNode(item.Name);
                    UIHierarchyItem parent = ((UIHierarchyItem)items.Parent);
                    InitiateCollection(item, root, parent);
                }                            
                else if (level == 2)
                {
                    UIHierarchyItem parent = ((UIHierarchyItem)items.Parent);
                    PopulateCollection(item, level, root, parent);
                }
                else if (level == 3)
                {
                    UIHierarchyItem parent = ((UIHierarchyItem)items.Parent);
                    PopulateCollection(item, level, root, parent);
                }
                else if (level == 4)
                {
                    UIHierarchyItem parent = ((UIHierarchyItem)items.Parent);
                    PopulateCollection(item, level, root, parent);
                }
                RecurseItems(item.UIHierarchyItems, level + 1, sb);
            }
        }

        public void InitiateCollection(UIHierarchyItem item, TreeNode root, UIHierarchyItem parent)
        {
            //ObservableCollection<TreeNode> TreeCollectionTemp = new ObservableCollection<TreeNode>();
            //TreeCollectionTemp.Add(root1);
            //TreeCollectionRobo.Add(root);
          //  this.Data = new SampleData();
            TreeCollection3.Add(root);
            this.TreeCollection3 = TreeCollection3;
        }

        public void PopulateCollection(UIHierarchyItem item, int level, TreeNode root, UIHierarchyItem parent)
        {
            if (level == 2)
            {
                root.Children.Add(new TreeNode(item.Name));
            }
            else if (level == 3)
            {
                foreach (var child in root.Children)
                {
                    if (child.Caption == parent.Name)
                    {
                        child.Children.Add(new TreeNode(item.Name));
                    }
                }
            }
            else if (level == 4)
            {
                foreach (var child in root.Children)
                {
                    var rootChild = root.Children;
                    foreach (var child1 in rootChild)
                    {
                        foreach (var child2 in child1.Children)
                        {
                            if (child2.Caption == parent.Name)
                            {
                                child2.Children.Add(new TreeNode(item.Name));
                            }
                        }
                    }
                }
            }
        }

        //private string GetSourceFilePath()
        //{
        //    DTE2 _applicationObject = GetCurrentDTE();
        //    UIHierarchy uih = _applicationObject.ToolWindows.SolutionExplorer;
        //    var activeWindow = _applicationObject.ActiveDocument.FullName;
        //    MessageBox.Show(activeWindow);

        //    ////To get selected item location
        //    //Array selectedItems = (Array)uih.SelectedItems;
        //    //if (null != selectedItems)
        //    //{
        //    //    foreach (UIHierarchyItem selItem in selectedItems)
        //    //    {
        //    //        ProjectItem prjItem = selItem.Object as ProjectItem;
        //    //        string filePath = prjItem.Properties.Item("FullPath").Value.ToString();
        //    //        //System.Windows.Forms.MessageBox.Show(selItem.Name + filePath);
        //    //        return filePath;
        //    //    }
        //    //}
        //    return string.Empty;
        //}
    }
}
